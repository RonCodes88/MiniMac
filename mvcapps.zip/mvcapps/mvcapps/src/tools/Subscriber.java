package tools;

public interface Subscriber {
    public void update();

}
